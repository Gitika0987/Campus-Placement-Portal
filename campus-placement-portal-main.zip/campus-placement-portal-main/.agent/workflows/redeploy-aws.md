---
description: Quick redeploy placement portal to AWS (after lab session restart)
---

# Quick AWS Redeploy Workflow

Use this when starting a fresh AWS Academy lab session to get the placement portal back up quickly.

## Prerequisites
- AWS Academy lab session is **active** (started from Vocareum)
- AWS CLI credentials are updated (copy from Vocareum → AWS Details → AWS CLI)

## Steps

### 1. Update AWS credentials
Copy the new credentials from Vocareum and paste into terminal:
```bash
# Paste the credentials block from Vocareum (AWS Details → Show → AWS CLI)
# It will look like:
# export AWS_ACCESS_KEY_ID=...
# export AWS_SECRET_ACCESS_KEY=...
# export AWS_SESSION_TOKEN=...
```

### 2. Create security group
// turbo
```bash
aws ec2 create-security-group --group-name placement-portal-sg --description "Placement Portal SG" --region us-east-1
```

### 3. Open required ports
// turbo
```bash
aws ec2 authorize-security-group-ingress --group-name placement-portal-sg --protocol tcp --port 22 --cidr 0.0.0.0/0 --region us-east-1
aws ec2 authorize-security-group-ingress --group-name placement-portal-sg --protocol tcp --port 5000 --cidr 0.0.0.0/0 --region us-east-1
aws ec2 authorize-security-group-ingress --group-name placement-portal-sg --protocol tcp --port 8080 --cidr 0.0.0.0/0 --region us-east-1
aws ec2 authorize-security-group-ingress --group-name placement-portal-sg --protocol -1 --source-group placement-portal-sg --region us-east-1
```

### 4. Create key pair
```bash
aws ec2 create-key-pair --key-name placement-key --query 'KeyMaterial' --output text --region us-east-1 > placement-key.pem
chmod 400 placement-key.pem
```

### 5. Launch 4 EC2 instances
```bash
aws ec2 run-instances \
    --image-id ami-0c02fb55956c7d316 \
    --instance-type t2.micro \
    --count 4 \
    --key-name placement-key \
    --security-groups placement-portal-sg \
    --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=placement-portal}]' \
    --region us-east-1
```

### 6. Get instance IPs (wait ~30s for instances to start)
// turbo
```bash
sleep 30
aws ec2 describe-instances \
    --filters "Name=tag:Name,Values=placement-portal" "Name=instance-state-name,Values=running" \
    --query 'Reservations[*].Instances[*].[InstanceId,PublicIpAddress,PrivateIpAddress]' \
    --output table --region us-east-1
```

### 7. Set up each Flask EC2 (repeat for 3 instances)
```bash
# SSH into each Flask EC2:
ssh -i placement-key.pem ec2-user@<FLASK-EC2-PUBLIC-IP>

# On the EC2, run:
sudo yum install -y git docker
sudo service docker start
sudo usermod -aG docker ec2-user

# Clone and build:
git clone <YOUR-REPO-URL> placement-portal
cd placement-portal
sudo docker build -t placement-backend .
sudo docker run -d --name placement-backend -p 5000:5000 placement-backend

# Verify:
curl http://localhost:5000/health
```

Or use scp + ec2_setup.sh:
```bash
# From your laptop:
scp -i placement-key.pem -r backend/ Dockerfile .dockerignore ec2_setup.sh ec2-user@<IP>:~/placement-portal/
ssh -i placement-key.pem ec2-user@<IP> "cd ~/placement-portal && chmod +x ec2_setup.sh && ./ec2_setup.sh"
```

### 8. Set up Nginx EC2 (4th instance)
```bash
ssh -i placement-key.pem ec2-user@<NGINX-EC2-PUBLIC-IP>

sudo yum install -y nginx

# Edit nginx config — replace PRIVATE IPs:
sudo nano /etc/nginx/nginx.conf
# Paste contents from nginx/nginx_aws.conf, update the 3 private IPs

sudo nginx -t
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 9. Update frontend API URL and redeploy to S3
```bash
# From your laptop — update API URL in both HTML files:
# Change: const API = "http://localhost:8080"
# To:     const API = "http://<NGINX-EC2-PUBLIC-IP>:8080"

# Then redeploy:
chmod +x deploy_frontend.sh
./deploy_frontend.sh <NGINX-EC2-PUBLIC-IP> campus-placement-portal-2026
```

### 10. Verify
```bash
# Test backend through load balancer:
curl http://<NGINX-EC2-PUBLIC-IP>:8080/health

# Open S3 URL in browser:
# http://campus-placement-portal-2026.s3-website-us-east-1.amazonaws.com
```
